%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
%    This is the main program that computes the solution of          %
%                                                                    %
%                    -u'' = f(x),   a <= x <= b, u(a)=u(b)=0         %
%                                                                    %
%    at various space mesh levels and computes the experimental      %
%    order of convergence (EOC) for the linear FEM the in the        %
%    L^2/H^1 error norms.                                            %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clc
clear all; 
close all;
format long
a=0; b=1;               % domain:=[a, b]
N=5;                    % No of elements 

LMAX=10;                % Maximum refinement level
for run = 1:LMAX        % Refine the mesh and solve the problem
  run
  N = 2*N;
  dx=(b-a)/N;
  x=a:dx:b;
  [uh,L2err,H1err,CN]=fem1d_solve(x);
  errL2(run)=L2err;
  errH1(run)=H1err;
  condA(run)=CN;
  NI(run)=N;
end;

fprintf('==============================================================================================\n');
fprintf('Lev.        L2-error        order       H1-error        order        Condition#          order\n');
fprintf('==============================================================================================\n');

for run = 1:LMAX
%_{
  if run > 1
    ordL2(run-1) =  log(errL2(run-1)/errL2(run))/log(2);
    ordH1(run-1) =  log(errH1(run-1)/errH1(run))/log(2);
    ordCN(run-1) =  log(condA(run)/condA(run-1))/log(2);
  end
  if run == 1
    fprintf('%4i    %12.5e   -----------  %12.5e   ------------    %12.5e   ------------ \n', NI(run), ...
                                                        errL2(run), errH1(run), condA(run))
  else
    fprintf('%4i    %12.5e   %12.3e %12.5e   %12.3e    %12.5e   %12.3e\n', NI(run), errL2(run), ordL2(run-1),...
                                                errH1(run), ordH1(run-1), condA(run),ordCN(run-1))
  end; 
  %_}
end  