
function y = f(x)

   y = 8;             % Example1
%    y = pi^2*sin(pi*x);  % Example2
%    y = pi^2*cos(pi*x);  % Example3

return
