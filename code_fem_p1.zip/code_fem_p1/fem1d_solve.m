function [u_fem,L2err,H1err,CN] = fem1d_solve(x)  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%                                                                    %
%    Simple Matlab code for 1D FEM for                               %
%                                                                    %
%                    -u'' = f(x),   a <= x <= b, u(a)=u(b)=0         %
%    Input: x, Nodal points                                          %
%    Output: U, FEM solution at nodal points                         %
%                                                                    %
%    Function needed: f(x).                                          %
%                                                                    % 
%    Matlab functions used:                                          %
%                                                                    %
%     hat2(x,x1,x2), hat function in [x1,x2] that is 1 at x2; and    %
%     0 at x1.                                                       %
%                                                                    %
%     hat1(x,x1,x2), hat function in [x1,x2] that is 0 at x1; and    %
%     1 at x1.                                                       %
%                                                                    %
%     int_hat2_f(x1,x2): Contribution to the load vector from hat2   %
%     int_hat1_f(x1,x2): Contribution to the load vector from hat1   %
%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
                              
M = length(x);
for i=1:M-1,
  h(i) = x(i+1)-x(i);
end

uL = exact_soln(x(1));                   % Left BC
uR = exact_soln(x(end));                 % Right BC

A = sparse(M,M); F=zeros(M,1);           % Initialize Matrxi & Rhs
A(1,1) = 1; F(1)=uL;                     % Implement the left BC
A(M,M) = 1; F(M)=uR;                     % Implement the Right BC

A(2,2) = 1/h(1); F(2) = int_hat2_f(x(1),x(2));
A(2,1) = -1/h(1);

for i=2:M-2,                            % Loop over the elements
  A(i,i) = A(i,i) + 1/h(i);
  A(i,i+1)   = A(i,i+1) - 1/h(i);
  A(i+1,i)   = A(i+1,i) - 1/h(i);
  A(i+1,i+1) = A(i+1,i+1) + 1/h(i);
  F(i)       = F(i) + int_hat1_f(x(i),x(i+1));
  F(i+1)     = F(i+1) + int_hat2_f(x(i),x(i+1));
end

  A(M-1,M-1) = A(M-1,M-1) + 1/h(M-1);
  A(M-1,M) = - 1/h(M-1);
  F(M-1)     = F(M-1) + int_hat1_f(x(M-1),x(M));
  CN=condest(A);
  u_fem = A\F;
  
%% Plot the FEM solution vs. Exact solution
xe=x(1):.01:x(end);   
u_exact = exact_soln(xe(:));
plot(x,u_fem,'+', xe,u_exact)   % Solid: the exact, %dotted: FEM solution
legend('FEM','Exact')
xlabel('x'); ylabel('u(x) & u_{fem}(x)'); 
title('Solid line: Exact solution, Dotted line: FEM solution')
pause(2)
shg
%% Compute error norm:

u_exact = exact_soln(x(:));
error = norm(u_fem-u_exact,2);  % Compute the infinity error
   
%%% Error Computation %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	[L2err,H1err,L0err] ...
			= Error(@exact_soln,@exact_soln_prime,x,u_fem,M,x);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
