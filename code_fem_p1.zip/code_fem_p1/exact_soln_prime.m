function u = exact_soln_prime(x)

  u = 4*(1-2*x);        % Example1
%   u=pi*cos(pi*x);       % Example2
%   u=-pi*sin(pi*x);      % Example3  
