
function y = hat1(x,x1,x2)

% This function evaluate the hat function of the form

    y = (x2-x)/(x2-x1);

  return
