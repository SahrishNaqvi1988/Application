function u = exact_soln(x)

   u = 4*x.*(1-x);     % Example1
%    u=sin(pi*x);        % Example2
%    u=cos(pi*x);        % Example3
