
function y = hat2(x,x1,x2)

% This function evaluate the hat function of the form

    y = (x-x1)/(x2-x1);

  return
