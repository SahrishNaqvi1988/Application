function [L2err,H1err,LI0err] ...
		= Error(ue,uprime,xp,uh,N,x)

[gn,gp,gw] = Gauss(10);

% number of local degree of freedom
% 2: linear
% 3: quadratic
feorder=1;
DOFloc = feorder + 1;

L2err = 0;
H1err = 0;

for j = 1:N-1
	id1 = (j-1)*(DOFloc-1) + 1;
	id2 = id1 + DOFloc-1;
	h = abs(xp(id2)-xp(id1));
	for q = 1:gn
		xloc = gp(q);
		xglo = xp(id1) + xloc*(xp(id2)-xp(id1));
		ufem = fem_soln(x,uh,xglo);
		upfem = fem_soln_prime(x,uh,xglo);
		uex = ue(xglo);
        uprimex = uprime(xglo);
		L2err = L2err + h*gw(q)*(uex - ufem)^2;	
		H1err = H1err + h*gw(q)*(uprimex - upfem)^2;
     end
end
H1err = sqrt(H1err + L2err);
L2err = sqrt(L2err);


for i = 1:length(xp)
    uex(i) = ue(xp(i));
end
LI0err = max(abs(uex'-uh));